import js from "@eslint/js";
import tseslint from "typescript-eslint";
import prettierConfig from "eslint-config-prettier";

export default tseslint.config(
  { ignores: [
      "dist/**",
      "node_modules/**",
      "*.config.*",
      "*.mjs",
      "*.cjs",
      "src/lib/**",
      "src/authz-runtime/**",
      "src/hypercore-runtime/**",
      "src/components/**",
      "src/hooks/**",
      "src/core/**",
      "src/cognition/moe/**",
      "src/cognition/rag/**",
      "src/memory/mesh/**",
      "src/learning/federated/**",
      "src/observability/**",
      "src/federation/tamv/**",
      "src/pipeline/hyper-turbo/**",
      "src/ui/app.js",
      "src/ui/chat-plus.js",
      "src/ui/integration.ts",
      "src/economy/revenue-fabric/storage.ts",
      "src/routes/revenue-fabric.ts",
      "src/multimodal/**",
      "src/security/bookpi-integrity.ts",
      "src/security/http-hardening.ts",
      "src/security/pqc/**",
      "src/security/secret-scanner.ts",
      "src/security/zero-trust/**",
      "src/governance/cognitive/**",
    ] },
  js.configs.recommended,
  ...tseslint.configs.recommended,
  {
    files: ["**/*.ts", "**/*.tsx"],
    languageOptions: {
      parserOptions: {
        project: ["./tsconfig.json", "./tsconfig.build.json"],
        tsconfigRootDir: import.meta.dirname,
      },
    },
    rules: {
      "@typescript-eslint/no-explicit-any": "off",
      "@typescript-eslint/no-unused-vars": "off",
      "@typescript-eslint/consistent-type-imports": "off",
      "@typescript-eslint/no-floating-promises": "off",
      "@typescript-eslint/no-misused-promises": "off",
      "@typescript-eslint/no-require-imports": "off",
      "no-control-regex": "off",
      "no-console": "off",
      "prefer-const": "off",
      "no-useless-escape": "off",
      "no-undef": "off",
      "no-misleading-character-class": "off",
    },
  },
  prettierConfig
);
